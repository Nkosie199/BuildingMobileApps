import ConfigStore from './config.store'

const config = new ConfigStore()

export default {config}