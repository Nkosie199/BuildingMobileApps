import React, { Component } from 'react';

export default class SplashScreen extends Component {
  constructor(props) {
    super(props)
  }
  render() {
    return null
  }
}