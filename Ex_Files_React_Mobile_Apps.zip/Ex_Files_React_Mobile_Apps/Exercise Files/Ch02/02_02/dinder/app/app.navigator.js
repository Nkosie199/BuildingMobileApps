import React from 'react';
import { DrawerNavigator } from 'react-navigation';

const RouteConfig = {}
const AppNavigator = DrawerNavigator({},RouteConfig)

export default AppNavigator;